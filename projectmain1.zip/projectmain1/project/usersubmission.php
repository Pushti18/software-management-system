<?php 
session_start();
    // $size = 2;
    //  $start = 0;
    // if(isset($_GET['paging'])){
    //     $start= (($_GET['paging'])-1)*2;
    // }

    require_once("dbcon.php");
    $count1 = mysqli_query($con,"SELECT COUNT(*) as total FROM indexconnection WHERE status=1");
    $row = $count1->fetch_assoc();
    // echo $row['total'];


    // exit(0);
    $size=7;
    $start=0;
    $totalpage = ceil($row['total']/$size);
    if(isset($_POST['paging'])){
        $start = (($_POST['paging'])-1)*$size;
    }
    
        $query = " select * from indexconnection where status=1 limit $start,$size";
        $result = mysqli_query($con,$query);
        $sql =  "select tbl_uploads.user,tbl_uploads.date,tbl_uploads.grades, tbl_uploads.file,registration.Username,tbl_uploads.Subject from tbl_uploads INNER JOIN registration on tbl_uploads.user = registration.id ";
        $result1 = mysqli_query($con,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Topic</title>
   
     <style>
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(45deg, greenyellow, dodgerblue);
  font-family: "Sansita Swashed", cursive;
} 

       </style>
</head>
</head>
<body class="bg-dark">


                                <center>
                        <table class="table table-bordered" border ="1" align = "center">
                            <tr>
                                <h2>File Submission</h2>
                                <td> ID </td>
                                <td>  Name </td>
                                <td> FILE </td>
                                <td> Subject </td>
                                <td> Time </td>
                                <td> Downloads </td>
                                <td> Grades </td>
                            </tr>

                            <?php 
                                    
                                    while($row1=$result1->fetch_assoc())
                                    {
                                        $user = $row1['user'];
                                        $file = $row1['file'];
                                        $name = $row1['Username'];
                                        $subject = $row1['Subject'];
                                        $id = $row1['user'];
                                        $date = $row1['date'];
                                        $grades = $row1['grades'];

                                        // $delete;
                            ?>
                                    <tr>
                                        <td><?php echo $user ?></td>
                                        <td><?php echo $name ?></td>
                                         <td><?php echo $file ?></td>
                                        <td><?php echo $subject ?></td>
                                        <td><?php echo $date ?></td>
                                        <td><a href="downlond_file.php?Del=<?php echo $id ?>">Downlond</a></td>
                                        <td><?php echo $grades ?></td>
                                    </tr>        
                            <?php 
                                    } 
                                    
                                    echo "</tr></table>";

                            ?>                                                                    
                                   

                        </table>
                                </center>
                    </div>
                </div>
            </div>
        </div>
        <!-- <a href="./view.php?paging=1">1</a><br>
        <a href="./view.php?paging=2">2</a><br>
        <a href="./view.php?paging=3">3</a> -->

</body>
</html>