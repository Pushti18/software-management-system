<?php
    session_start();
    require_once("dbcon.php");

    if(isset($_POST['submit']))
    {
        if(empty($_POST['Subject']))
        {
            echo ' Please Fill in the Blanks ';
        }
        else
        {
           
            $TopicName= $_POST['Subject'];
       
    
        
            $query = " INSERT into subject (subjects) values('$TopicName')";
            // echo $query;
            // exit(0);
            $result = mysqli_query($con,$query);

            if($result)
            {
                header("location:admindashboard.php");
            }
            else
            {
                echo '  Please Check Your Query ';
            }
         }
    }
    else
    {
        header("location:index.php");
    }



?>

