<?php 
    // $size = 2;
    //  $start = 0;
    // if(isset($_GET['paging'])){
    //     $start= (($_GET['paging'])-1)*2;
    // }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content=="IE=edge"/>
<meta name="google" value="notranslate"/>
<title>Side Menu</title>

<link rel="stylesheet" type="text/css" href="css/dashboard.css">
<link rel="stylesheet" type="text/css" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Topic</title>
         <style>
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(45deg, greenyellow, dodgerblue);
  font-family: "Sansita Swashed", cursive;
}  
* {box-sizing: border-box;}


img{
  position:absolute;
    top:0.1%;
    left:0.5%;
  margin-left:3%;
   overflow: hidden;
  background-color: #f1f1f1;
  /* padding: 20px 10px; */
  height:90px;
  width:100px;
} 
.header {
  margin-left: 10%;
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
}

.header-right {
  float: right;
}

@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  
  .header-right {
    float: none;
  }
}
       </style>
</head>
<body class="bg-dark">
<nav class="main-menu">


  
 <div>
    <a class="logo" href="./images.Project Hub_logo.png">
    </a> 
  </div> 
<div class="settings"></div>
<div class="scrollbar" id="style-1">
      
<ul>
 <li>                                   

</a>
</li> 

<li>                                   
<a href="./dashboard.php">
<i class="fa fa-home fa-lg"></i>
<span class="nav-text">Dashboard</span>
</a>
</li>   
   
<li>                                 
<a href="./login.php">
<i class="fa fa-user fa-lg"></i>
<span class="nav-text">Logout</span>
</a>
</li>   

    
<!-- <li>                                 
<a href="./index2.php">

<i class="fa fa-duotone fa-filter fa=lg"></i>
<span class="nav-text">Topics</span>
</a>
</li>    -->
<li>
                                   
<a href="./help.php">
  <i class="fa fa-question-circle fa-lg"></i>

<span class="nav-text">Help</span>
</a>
</li> 
<li>
                                   
<a href="./pstask.php">
  <i class="fa fa-book" aria-hidden="true"></i>

<span class="nav-text">Task</span>
</a>
</li>   
<!-- <li>
                                   
<a href="./">
<i class="fa fa-duotone fa-comments fa-lg"></i>
<span class="nav-text">Discussion</span>
</a>
</li>    -->

<li>
                                   
<a href="./file.php">
<i class="fa fa-duotone fa-check fa-lg"></i>
<span class="nav-text">Submission</span>
</a>
</li>  
    
  

        </nav>
        <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card mt-5">
                        <center>
                        <table class="table table-bordered" border ="1" align = "center">
                            <tr>
                                <td> ID </td>
                                <br>
                                <td> Topic </td>
                                <td> RollNo </td>
                                <td> Subject </td>
                                <td> Teacher </td>
                                <br>
                            </tr>

                            <?php 
                                require_once("dbcon.php");
                                $count1 = mysqli_query($con,"SELECT COUNT(*) as total FROM indexconnection WHERE Subject = 'PS'");
                                $row = $count1->fetch_assoc();
  
                                $size=4;
                                $start=0;
                                $totalpage = ceil($row['total']/$size);
                                if(isset($_POST['paging'])){
                                    $start = (($_POST['paging'])-1)*$size;
                                }
                                
                                    $query = " SELECT * from indexconnection where Subject = 'PS' AND `status`= 1 limit $start,$size";
                                    $result = mysqli_query($con,$query);

                                    while($row=$result->fetch_assoc())
                                    {
                                        $ID = $row['id'];
                                        $TopicName = $row['Topic'];
                                        $RollNo = $row['RollNo'];
                                        $Subject = $row['Subject'];
                                        $Teacher = $row['Teacher'];
                            ?>
                                    <tr>
                                        <td><?php echo $ID ?></td>
                                        <td><?php echo $TopicName ?></td>
                                        <td><?php echo $RollNo ?></td>
                                        <td><?php echo $Subject ?></td>
                                        <td><?php echo $Teacher ?></td>
                                        <!-- <td><a href="edit.php?ID=<?php echo $ID ?>">Edit</a></td>
                                        <td><a href="update.php?Del=<?php echo $ID ?>">Delete</a></td> -->
                                    </tr>        
                            <?php 
                                    } 
                                    echo "<table><tr>";
                                    for ($i=1; $i <= $totalpage ; $i=$i+1) { 
                                        echo "<td>
                                        <form method='post' action='./iwt.php'>
                                            <input type='hidden' name='paging' value='$i'></input>
                                            <button type='submit' name='submit' value='$i'>$i</button>
                                        </form>
                                        </td>";
                                    }
                                    echo "</tr></table>";

                            ?>                                                                    
                                   

                        </table>
                                </center>
                    </div>
                </div>
            </div>
        </div>

        
      
    
</body>
</html>