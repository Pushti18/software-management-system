<?php 
session_start();
error_reporting(0);
?>


<!DOCTYPE html><html class="menu">
<html>

<head>

<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content=="IE=edge"/>
<meta name="google" value="notranslate"/>
<title>Side Menu</title>

<link rel="stylesheet" type="text/css" href="css/dashboard.css">
<link rel="stylesheet" type="text/css" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box;}

body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
img{
  position:absolute;
    top:0.1%;
    left:0.5%;
  margin-left:3%;
   overflow: hidden;
  background-color: #f1f1f1;
  /* padding: 20px 10px; */
  height:90px;
  width:100px;
} 
.header {
  margin-left: 10%;
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
}

.header-right {
  float: right;
}

@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  
  .header-right {
    float: none;
  }
}

.flex{
  display: flex;
}
</style>

  
 



</head>
<body>
<img src="./images/img1.jpg">
<div class="header" >
   
  <a href="#default" class="logo">Project Hub</a>
  
</div>



</div><nav class="main-menu">


  
 <div>
    <a class="logo" href="./images.Project Hub_logo.png">
    </a> 
  </div> 
<div class="settings"></div>
<div class="scrollbar" id="style-1">
      
<ul>
 <li>                                   

<span style="color:black;"><?php echo $_SESSION['username']; ?></span>
</a>
</li> 

<li>                                   
<a href="./dashboard.php">
<i class="fa fa-home fa-lg"></i>
<span class="nav-text">Dashboard</span>
</a>
</li>   
   
<li>                                 
<a href="./login.php">
<i class="fa fa-user fa-lg"></i>
<span class="nav-text">Logout</span>
</a>
</li>   

    
<li>                                 
<a href="./index2.php">

<i class="fa fa-duotone fa-filter fa=lg"></i>
<span class="nav-text">Topics</span>
</a>
</li>   
<li>
                                   
<a href="./help.php">
  <i class="fa fa-question-circle fa-lg"></i>

<span class="nav-text">Help</span>
</a>
</li> 
<!-- <li>
                                   
<a href="./taskadmin.php">
  <i class="fa fa-question-circle fa-lg"></i>

<span class="nav-text">Task</span>
</a>
</li>    -->
<!-- <li>
                                   
<a href="./">
<i class="fa fa-duotone fa-comments fa-lg"></i>
<span class="nav-text">Discussion</span>
</a>
</li>    -->

<!-- <li>
                                   
<a href="./file.php">
<i class="fa fa-duotone fa-check fa-lg"></i>
<span class="nav-text">Submission</span>
</a>
</li>   -->
<li>
                                   
<a href="./usersubmission.php">
<i class="fa fa-book" aria-hidden="true"></i>
<span class="nav-text">Submission Done</span>
</a>
</li>
  

        </nav>
      
        <div class="main-container">
  <div class="heading">
    <h1 class="heading__title">Dashboard</h1>
    <!-- <p class="heading__credits"><a class="heading__link" target="_blank" href="https://dribbble.com/sl">Design by Simon Lurwer on Dribbble</a></p> -->
  </div>
  <div class="cards">
    <div class="card card-1">
      <div>
     <a href="./demp.php?Subject=IWT">
      <h1 class="card__title">IWT</h1>
</div>
    </div>
    <!-- <div class="card card-2">
      <div>
       <a href="./demp.php?Subject=OS" >
      <h1 class="card__title">OS</h1>
</div>
    </div>
    <div class="card card-3">
      <div>
       <a href="./demp.php?Subject=ADC">
      <h1 class="card__title">ADC</h1>
</div>
    </div>
    <div class="card card-4">
    <div>
       <a href="./demp.php?Subject=MCI">
      <h1 class="card__title">MCI</h1>
</div>
    </div>
    <div class="card card-5">
      <div>
       <a href="./demp.php?Subject=PS">
      <h1 class="card__title">PS</h1>
</div>
    </div>
    <div class="card card-1">
     <div>
       <a href="./demp.php?Subject=DBMS">
      <h1 class="card__title">DBMS</h1>
</div>
    </div> -->

  <?php
    include('./dbcon.php');
    $sql = "SELECT DISTINCT subjects from `subject`";
    $result  = $con -> query($sql);
    if ($result->num_rows > 0) 
    {
      while($row = $result->fetch_assoc()) 
      {
  ?>
        <div class="card card-1 flex"> 
          <div>
              <a href="./demp.php?subject=<?php echo $row['subjects']; ?>">
                <h1 class="card__title"><?php echo $row['subjects'];?></h1>
              </a>
          </div>  
        </div>
  <?php 
      }
    }

  ?>

</div>

  
</body>
</html>