<?php
    require_once("dbcon.php");
    session_start();

    $id = $_GET['user_id'];
    $sql1 = "SELECT * from registration WHERE id =  $id";
    $result = mysqli_query($con,$sql1);
    $row1 = $result -> fetch_assoc();
    echo $row1['email'];

    require_once("./include/PHPMailer.php");    
    require_once("./include/SMTP.php");

    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->Username = 'ax637175@gmail.com';
        $mail->Password = 'abc@1801';

        $mail->setFrom('ax637175@gmail.com', 'Project Hub');
        $mail->addAddress($row1['email']);
    
        $mail->IsHTML(true);
        $mail->Subject = "Assignment Graded";
        $mail->Body = 'Recent Project Hub Notifications';
        $mail->AltBody = 'Your Assignment has been graded';

        $mail->send();
        echo "Email message sent.";
    } 
    catch (Exception $e) 
    {
        echo "Error in sending email. Mailer Error: {$mail->ErrorInfo}";
    }
?>
