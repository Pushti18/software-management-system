<?php
    header("Location:./admindashboard.php");
    
?>