<!DOCTYPE html>
<html>
<style>
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(45deg, greenyellow, dodgerblue);
  font-family: "Sansita Swashed", cursive;
} 
    </style>

<?php
    $uid = $_GET['uid'];
    $connect = mysqli_connect('localhost', 'root', '', 'pbl');

    $sql = "SELECT * FROM tbl_uploads WHERE user = $uid";

    $result = $connect->query($sql);
    echo "<table border='1'><th>File</th><th>User</th><th>Subject</th><th>Download</th>";
    while($row=$result->fetch_assoc()){
        echo "<tr>";
            echo "<td>";
            echo $row["file"];
            echo "</td>";

            echo "<td>";
            echo $row["user"];
            echo "</td>";

            echo "<td>";
            echo $row["Subject"];
            echo "</td>";

           

            echo "<td>";
            echo "<button>Download</button>";
            echo "</td>";
        echo "</tr>";

    }
    echo "</table>";

?>
</html>