<?php 
    // $size = 2;
    //  $start = 0;
    // if(isset($_GET['paging'])){
    //     $start= (($_GET['paging'])-1)*2;
    // }

    require_once("dbcon.php");
    $count1 = mysqli_query($con,"SELECT COUNT(*) as total FROM indexconnection WHERE status=1");
    $row = $count1->fetch_assoc();
    // echo $row['total'];


    // exit(0);
    $size=7;
    $start=0;
    $totalpage = ceil($row['total']/$size);
    if(isset($_POST['paging'])){
        $start = (($_POST['paging'])-1)*$size;
    }
    
        $query = " select * from indexconnection where status=1 limit $start,$size";
        $result = mysqli_query($con,$query);
        $sql =  "select tbl_uploads.user, tbl_uploads.file,registration.Username,tbl_uploads.Subject from tbl_uploads INNER JOIN registration on tbl_uploads.user = registration.id ";
        $result1 = mysqli_query($con,$sql);
        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Topic</title>
   
     <style>
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(45deg, greenyellow, dodgerblue);
  font-family: "Sansita Swashed", cursive;
} 

       </style>
</head>
</head>
<body class="bg-dark">

        <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card mt-5" style="margin-top: 11%; margin-right: 55%;">
                        <center>
                        <table class="table table-bordered" border ="1" align = "center">
                            <tr>
                                 <h2>Topic Selection</h2>
                                <td> ID </td>
                                <br>
                                <td> Topic </td>
                                <td> RollNo </td>
                                <td> Subject </td>
                                <td> Teacher </td>
                                <td> Status </td>
                                <td> Status </td>
                                <br>
                            </tr>

                            <?php 
                                    
                                    while($row=$result->fetch_assoc())
                                    {
                                        $ID = $row['id'];
                                        $TopicName = $row['Topic'];
                                        $RollNo = $row['RollNo'];
                                        $Subject = $row['Subject'];
                                        $Teacher = $row['Teacher'];

        
                            ?>
                                    <tr>
                                        <td><?php echo $ID ?></td>
                                        <td><?php echo $TopicName ?></td>
                                        <td><?php echo $RollNo ?></td>
                                        <td><?php echo $Subject ?></td>
                                        <td><?php echo $Teacher ?></td>
                                        <td><a href="edit.php?ID=<?php echo $ID ?>">Edit</a></td>
                                        <td><a href="update.php?Del=<?php echo $ID ?>">Delete</a></td>
                                    </tr>        
                            <?php 
                                    } 
                                    echo "<table><tr>";
                                    for ($i=1; $i <= $totalpage ; $i=$i+1) { 
                                        echo "<td>
                                        <form method='post' action='./view.php'>
                                            <input type='hidden' name='paging' value='$i'></input>
                                            <button type='submit' name='submit' value='$i'>$i</button>
                                        </form>
                                        </td>";
                                    }
                                    echo "</tr></table>";

                            ?>                                                                    
                                   

                        </table>
                                </center>



                                
        <!-- <a href="./view.php?paging=1">1</a><br>
        <a href="./view.php?paging=2">2</a><br>
        <a href="./view.php?paging=3">3</a> -->
   
</body>
</html>