<?php 

    require_once("dbcon.php");
    $ID = $_GET['ID'];
    $query = " select * from indexconnection where id=".$ID;
    $result = mysqli_query($con,$query);

    $row=$result->fetch_assoc();
    $ID = $row['id'];
    $TopicName = $row['Topic'];
    $RollNo = $row['RollNo'];
    $Subject= $row['Subject'];
    $Teacher= $row['Teacher'];
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Document</title>
</head>
<body class="bg-dark">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 m-auto">
                    <div class="card mt-5">
                        <div class="card-title">
                        </div>
                        <div class="card-body">

                            <form action="update.php?ID=<?php echo $ID ?>" method="post">
                                <input type="text" class="form-control mb-2" placeholder="Title " name="Topic" value="<?php echo $TopicName ?>">
                                <input type="text" class="form-control mb-2" placeholder="enter" name="RollNo" value="<?php echo $RollNo ?>">
                                <select name="Subject">
                                    <option value="IWT" <?php if($row['Subject']=="IWT"){echo "selected";}?> >IWT</option>
                                    <option value="OS" <?php if($row['Subject']=="OS"){echo "selected";}?> >OS</option>
                                    <option value="MCI" <?php if($row['Subject']=="MCI"){echo "selected";}?> >MCI</option>
                                    <option value="PS" <?php if($row['Subject']=="PS"){echo "selected";}?>>PS</option>
                                    <option value="ADC" <?php if($row['Subject']=="ADC"){echo "selected";}?>>ADC</option>
                                    <option value="DBMS" <?php if($row['Subject']=="DBMS"){echo "selected";}?>>DBMS</option><br>
                                </select>
                                <select name="Teacher">
                                    <option value="Prof.Chandrasigh Parmar" <?php if($row['Teacher']=="Prof.Chandrasigh Parmar"){echo "selected";}?> >Prof.Chandrasigh Parmar</option>
                                    <option value="Kapil Shukla" <?php if($row['Teacher']=="Kapil Shukla"){echo "selected";}?> >Kapil Shukla</option>
                                    <option value="Rakesh Oza" <?php if($row['Teacher']=="Rakesh Oza"){echo "selected";}?> >Rakesh Oza</option>
                                    <option value="Foram Rajdev" <?php if($row['Teacher']=="Foram Rajdev"){echo "selected";}?>>Foram Rajdev</option>
                                    <option value="Krupali Rana" <?php if($row['Teacher']=="Krupali Rana"){echo "selected";}?>>Krupali Rana</option>
                                    <option value="Kavan Dave" <?php if($row['Teacher']=="Kavan Dave"){echo "selected";}?>>Kavan Dave</option>
                                    <option value="Utsav Upadhyay" <?php if($row['Teacher']=="Utsav Upadhyay"){echo "selected";}?>>Utsav Upadhyay</option>
                                    <option value="Harshul Yagnik" <?php if($row['Teacher']=="Harshul Yagnik"){echo "selected";}?>>Harshul Yagnik</option><br>
                                </select>

                                <button class="btn btn-primary" name="update">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
</body>
</html>