<!DOCTYPE html>
<html lang="en">
<head>
    <title>Project</title>
   <style>
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(45deg, greenyellow, dodgerblue);
  font-family: "Sansita Swashed", cursive;
}

       </style>
</head>
<body class="bg-dark">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 m-auto "style="text-align: center; margin-top: 8%;">
                    <div class="card mt-5">
                        <div class="card-title">
                        </div>
                        <div class="card-body">

                            <form action="admininsert.php" method="post">
                               <h2>Task</h2>
                                <input type="text" class="form-control mb-2" placeholder="Task" name="Task" ></div><br>
                                <!-- <input type="text" class="form-control mb-2" placeholder="RollNo" name="RollNo" ></div><br> -->
                                <input type = "select" class="form-control mb-2" placeholder="Subject" name="Subject" ></div>
                                <!-- <select name="Subject" id="">
                                    <option class="s1" value="IWT">IWT</option>
                                    <option class="s2" value="OS">OS</option>
                                    <option class="s3" value="MCI">MCI</option>
                                    <option class="s4" value="PS">PS</option>
                                    <option class="s5" value="ADC">ADC</option>
                                    <option class="s6" value="DBMS">DBMS</option><br>
                                </select> -->
                                <!-- <select name="Teacher" id="">
                                    <option class="s1" value="Prof.Chandrasigh Parmar">Prof.Chandrasigh Parmar</option>
                                    <option class="s2" value="Kapil Shukla">Kapil Shukla</option>
                                    <option class="s3" value="Rakesh Oza">Rakesh Oza</option>
                                    <option class="s4" value="Foram Rajdev">Foram Rajdev</option>
                                    <option class="s5" value="Krupali Rana">Krupali Rana</option>
                                    <option class="s6" value="Kavan Dave">Kavan Dave</option>
                                    <option class="s7" value="Utsav Upadhyay">Utsav Upadhyay</option>
                                    <option class="s8" value="Harshul Yagnik">Harshul Yagnik</option><br>
                                </select> -->
                                <br>
                                <button style="margin-top: 2%;" class="btn btn-primary" name="submit">Insert</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    
</body>
</html>