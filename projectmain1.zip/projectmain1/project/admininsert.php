<?php
    session_start();
    require_once("dbcon.php");

    if(isset($_POST['submit']))
    {
        if(empty($_POST['Task']))
        {
            echo ' Please Fill in the Blanks ';
        }
        else
        {
           
            $TopicName= $_POST['Task'];
       
            $Subject = $_POST['Subject'];
        
            $query = " insert into task (Task,Subject) values('$TopicName','$Subject')";
            // echo $query;
            // exit(0);
            $result = mysqli_query($con,$query);

            if($result)
            {
                header("location:admindashboard.php");
            }
            else
            {
                echo '  Please Check Your Query ';
            }
         }
    }
    else
    {
        header("location:index.php");
    }



?>

