<?php 
    // $size = 2;
    //  $start = 0;
    // if(isset($_GET['paging'])){
    //     $start= (($_GET['paging'])-1)*2;
    // }
    require_once("dbcon.php");
    // $count1 = mysqli_query($con,"SELECT COUNT(*) as total FROM indexconnection WHERE Subject = 'IWT'");
    // $row = $count1->fetch_assoc();
    // echo $row['total'];


    // exit(0);
    // $size=1;
    // $start=0;
    // $totalpage = ceil($row['total']/$size);
    // if(isset($_POST['paging'])){
    //     $start = (($_POST['paging'])-1)*$size;
    // }
    
        // $query = " SELECT * from indexconnection where Subject = 'IWT' AND `status`= 1 limit $start,$size";
        // $result = mysqli_query($con,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Topic</title>
         <style>
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(45deg, greenyellow, dodgerblue);
  font-family: "Sansita Swashed", cursive;
} 

       </style>
</head>
<body class="bg-dark">

       <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card mt-5">
                        <center>
                        <table class="table table-bordered" border ="1" align = "center">
                            <tr>
                                <td> Task </td>
                                <br>
                                <!-- <td> Subject </td>
                                <br> -->
                                <td> Submission </td>
                                <br>
                            </tr>

                            <?php 
                            $subject = $_GET['Subject'];
                            $_SESSION['sub'] = $subject;
                                
                                $count1 = mysqli_query($con,"SELECT COUNT(*) as total FROM task WHERE Subject = '$subject'");
                                
                                $row = $count1->fetch_assoc();

                                $size=1;
                                $start=0;
                                $totalpage = ceil($row['total']/$size);
                                if(isset($_POST['paging'])){
                                    $start = (($_POST['paging'])-1)*$size;
                                }
                                
                                    $query = " SELECT * from task where Subject = '$subject' limit $start,$size";
                                    $result = mysqli_query($con,$query);
                                    
                                    while($row1=$result->fetch_assoc())
                                    {
                                        $Task = $row1['Task'];
                                        $Subject = $row1['Subject'];
                                        $Submission = $row1['Submission'];
                            ?>
                                        <td><?php echo $Task ?></td>
                                        <!-- <td><?php echo $Subject ?></td> -->
                                      
                                         <td><a href="file.php?Subject=<?php echo $Subject ?>">Submission</a></td>
                                    <!-- <td><a href="update.php?Del=<?php echo $ID ?>">Delete</a></td>  -->
                                    </tr>        
                            <?php 
                                    } 
                                    echo "<table><tr>";
                                    for ($i=1; $i <= $totalpage ; $i=$i+1) { 
                                        echo "<td>
                                        <form method='post' action='./iwttask.php?Subject=$subject'>
                                            <input type='hidden' name='paging' value='$i'></input>
                                            <button type='submit' name='submit' value='$i'>$i</button>
                                        </form>
                                        </td>";
                                    }
                                    echo "</tr></table>";

                            ?>                                                                    
                                   

                        </table>
                                </center>
                    </div>
                </div>
            </div>
        </div>
      
    
</body>
</html>