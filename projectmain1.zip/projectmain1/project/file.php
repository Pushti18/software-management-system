<?php error_reporting(0); ?>
<!DOCTYPE html>

<html>
<head>
  <title>File Upload</title>
<style>
 @import url("https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@600&display=swap");
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(45deg, greenyellow, dodgerblue);
  font-family: "Sansita Swashed", cursive;
}
.center {
  position: relative;
  padding: 50px 50px;
  background: #fff;
  border-radius: 10px;
}
.center h1 {
  font-size: 2em;
  border-left: 5px solid dodgerblue;
  padding: 10px;
  color: #000;
  letter-spacing: 5px;
  margin-bottom: 60px;
  font-weight: bold;
  padding-left: 10px;
}
.center .inputbox {
  position: relative;
  width: 300px;
  height: 50px;
  margin-bottom: 50px;
}
.center .inputbox input {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  border: 2px solid #000;
  outline: none;
  background: none;
  padding: 10px;
  border-radius: 10px;
  font-size: 1.2em;
}
.center .inputbox:last-child {
  margin-bottom: 0;
}
.center .inputbox span {
  position: absolute;
  top: 14px;
  left: 20px;
  font-size: 1em;
  transition: 0.6s;
  font-family: sans-serif;
}
.center .inputbox input:focus ~ span,
.center .inputbox input:valid ~ span {
  transform: translateX(-13px) translateY(-35px);
  font-size: 1em;
}
.center .inputbox [type="button"] {
  width: 50%;
  background: dodgerblue;
  color: #fff;
  border: #fff;
}
.center .inputbox:hover [type="button"] {
  background: linear-gradient(45deg, greenyellow, dodgerblue);
}

  </style>
</head>
<body>

<div class="center">
  <h1>Submissions</h1>

<?php 
session_start();
echo "  submit your files here!";
$subject = $_GET['Subject'];
$_SESSION['sub'] = $subject;

// echo "Subject Name: " . $_SESSION['iwt'];
// echo $_SESSION['sub'];
// exit(0);

?>
  <form action="file.php?upload=1&Subject=<?php echo $_SESSION['sub'];?>" method="post" enctype="multipart/form-data">
    <div class="inputbox">
      <input type="file" name="fileToUpload" />
    </div>

    <div class="inputbox">
      <button type="submit" name="upload">upload</button>
    </div>
  </form>
</div>

</body>
</html>


<?php
$server = "localhost";
$user= "root";
$password= "";
$db= "pbl";
$con = mysqli_connect($server,$user,$password,$db);



$id = 1;
//$target_dir = "../../upload/";
$target_dir = "D:/Software/xeemp/htdocs/upload/'".$_SESSION['sub']."'/".$_SESSION['username']."/";

$_SESSION['target_dir'];

$target_dir1 = "D:/Software/xeemp/htdocs/upload/'".$_SESSION['sub']."'/";

 if(!file_exists($target_dir1)){
    mkdir($target_dir1);
  // if(!file_exists($target_dir)){

  // }
 }
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$file = rand(1000,100000)."-".$_FILES['fileToUpload']['name'];
$file_loc = $_FILES['fileToUpload']['name'];
 $file_size = $_FILES['fileToUpload']['size'];
 $file_type = $_FILES['fileToUpload']['type'];
  //$final_file=str_replace(' ','-',$new_file_name);
 $folder="upload/";

// Allow certain file formats
if($imageFileType != "pdf" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" && $imageFileType != "jpg"&& $imageFileType != "zip" && $imageFileType != "docx" && $imageFileType != "doc") {
  // echo "  submit your files here!";
  $uploadOk = 0;
}
if(isset($_GET["upload"])){
// Check if $uploadOk is set to 0 by an error
// echo $target_file;
// exit(0);
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  
  if(!file_exists($target_dir)){
    mkdir($target_dir);
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
      $sql = "INSERT into tbl_uploads (file, type,user,Subject,date) values ('$file_loc','$file_size',".$_SESSION["user_id"].",'$subject',now())";
      
    //   mysqli_query($con,$sql);
      $con->query($sql);
    
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
  }
  else{
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
      $sql = "INSERT into tbl_uploads (file, type,user,Subject,date) values ('$file_loc','$file_size',".$_SESSION["user_id"].",'$subject',now())";
    //   mysqli_query($con,$sql);
      $con->query($sql);
    
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
}
}

?>
  
