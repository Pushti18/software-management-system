<?php 
    // $size = 2;
    //  $start = 0;
    // if(isset($_GET['paging'])){
    //     $start= (($_GET['paging'])-1)*2;
    // }

    require_once("dbcon.php");
    session_start();
    $count1 = mysqli_query($con,"SELECT COUNT(*) as total FROM indexconnection WHERE status=1");
    $row = $count1->fetch_assoc();
    // echo $row['total'];

    // exit(0);
    $size=7;
    $start=0;
    $totalpage = ceil($row['total']/$size);
    if(isset($_POST['paging'])){
        $start = (($_POST['paging'])-1)*$size;
    }
    
        $query = " select * from indexconnection where status=1 limit $start,$size";
        $result = mysqli_query($con,$query);
        $sql =  "select tbl_uploads.id,tbl_uploads.date, tbl_uploads.user, tbl_uploads.file,registration.Username,tbl_uploads.Subject from tbl_uploads INNER JOIN registration on tbl_uploads.user = registration.id ";
        $result1 = mysqli_query($con,$sql);
        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Topic</title>
   
     <style>
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(45deg, greenyellow, dodgerblue);
  font-family: "Sansita Swashed", cursive;
} 

.table{
    margin-top: 20%;
}
       </style>
</head>
</head>
<body class="bg-dark">

        <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card mt-5">
                      
                    <center>
                        <table class="" border ="1" align = "center">
                            <tr>
                                <h2>File Submission</h2>
                                <td> ID </td>
                                <td>  Name </td>
                                <td> FILE </td>
                                <td> Subject </td>
                                <td>Time </td>
                                <td>Downloads</td>
                                <td>Grades</td>
                            </tr>

                            <?php 
                                    
                                    while($row1=$result1->fetch_assoc())
                                    {
                                        $id_table = $row1['id'];

                                        $user = $row1['user'];
                                        $file = $row1['file'];
                                        $name = $row1['Username'];
                                        $subject = $row1['Subject'];
                                        $id = $row1['user'];
                                        $date = $row1['date'];
                            ?>
                                    <tr>
                                        <td><?php echo $user ?></td>
                                        <td><?php echo $name ?></td>
                                         <td><?php echo $file ?></td>
                                        <td><?php echo $subject ?></td>
                                        <td><?php echo $date ?></td>
                                        <td><a href="downlond_file.php?Del=<?php echo $id ?>">Downlond</a></td>
                                        <td>
                                            <form method="POST">
                                                <input type="text" name="grade"></input>
                                                <input type="submit" name="btn<?php echo $id_table;?>"></input>
                                            </form>

                                            <?php
                                                if(isset($_POST['btn'.$id_table]))
                                                {    
                                                    require_once("dbcon.php");
                                                    $grade=$_POST['grade'];
                                                    $value =  "UPDATE tbl_uploads SET `grades` = $grade WHERE id = $id_table ";
                                                    $sql1 = "SELECT * FROM tbl_uploads WHERE id = $id_table";
                                                    $result4 = $con->query($sql1);
                                                    $row3 = $result4->fetch_assoc();
                                                    if($result2 = mysqli_query($con,$value))
                                                    {
                                                        // $row2 = $result2->fetch_assoc();
                                            ?>
                                                        <script> window.location.href = './mail_process.php?user_id=<?php echo $row3['user']; ?>'; </script>
                                            <?php
                                                    }
                                                }
                                            ?>       
                                        </td>    
                                    </tr>  
                                    
                            <?php 
                                    } 
                                    
                                    echo "</tr></table>";
                                    

                            ?>                                                                    
                                   

                        </table>
                                </center>
                    </div>
                </div>
            </div>
        </div>
        <!-- <a href="./view.php?paging=1">1</a><br>
        <a href="./view.php?paging=2">2</a><br>
        <a href="./view.php?paging=3">3</a> -->
   
</body>
</html>