<?php

//  ;

session_start();
// $emp_id = $_GET['Del'];
// $sql = "SELECT file  FROM tbl_uploads where user = '$emp_id'";

// $result = mysqli_query($con,$sql);

//     if($result){
// 	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
// 	$file = $row['file'];

// 	$path = $_SESSION['target_dir'];
// 	$pdf = ".pdf";
	echo $_SESSION['target_dir'];
	// <iframe src="$path"></iframe>
    

?>