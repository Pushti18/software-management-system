<?php 
session_start();
error_reporting(0);
?>


<!DOCTYPE html><html class="menu">
<html>

<head>

<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content=="IE=edge"/>
<meta name="google" value="notranslate"/>
<title>Side Menu</title>

<link rel="stylesheet" type="text/css" href="css/dashboard.css">
<link rel="stylesheet" type="text/css" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box;}

body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
img{
  position:absolute;
    top:0.1%;
    left:0.5%;
  margin-left:3%;
   overflow: hidden;
  background-color: #f1f1f1;
  /* padding: 20px 10px; */
  height:90px;
  width:100px;
} 
.header {
  margin-left: 10%;
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
}

.header-right {
  float: right;
}

@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  
  .header-right {
    float: none;
  }
}

.topics {
  margin-left: 10%;
  margin-top: 5%;
  height: 50px;
  width: 10%;
}

</style>

</head>
<body>

<img src="./images/img1.jpg">
<div class="header" >
   
  <a href="#default" class="logo">Project Hub</a>
  
</div>

<div>
  <tr>
    <td>
      <a href="./view.php">
      <input type=submit value="Topic" class="topics">
</td>
<td>
      <a href="./viewsub.php">
      <input type=submit value="Submissions" class="topics">
    </td>
</tr>
</div>
  

</div><nav class="main-menu">


  
 <div>
    <a class="logo" href="./images.Project Hub_logo.png">
    </a> 
  </div> 
<div class="settings"></div>
<div class="scrollbar" id="style-1">
      
<ul>
 <li>                                   

<span style="color:black;"><?php echo $_SESSION['admin']; ?></span>
</a>
</li> 

 
   
<!-- <li>                                 
<a href="./view.php">
<i class="fa fa-duotone fa-filter fa=lg"></i>
<span class="nav-text">Submissions</span>
</a>
</li>    -->
<li>                                 
<a href="./login.php">
<i class="fa fa-user fa-lg"></i>
<span class="nav-text">Logout</span>
</a>
</li> 
<li>                                 
<a href="./index3.php">
<i class="fa fa-search" aria-hidden="true"></i>
<span class="nav-text">Search</span>
</a>
</li> 
<li>                                 
<a href="./admintask.php">
<i class="fa fa-book" aria-hidden="true"></i>
<span class="nav-text">Task</span>
</a>
</li> 
<li>                                 
<a href="./adminsubject.php">
<i class="fa fa-credit-card" aria-hidden="true"></i>
<span class="nav-text">Create Subject</span>
</a>
</li> 

    </div>
  </div>
 
</div>

</body>
</html>