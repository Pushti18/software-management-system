<?php 

    require_once("dbcon.php");

    if(isset($_POST['update']))
    {
        $ID = $_GET['ID'];
        $TopicName = $_POST['Topic'];
        $Subject=$_POST['Subject'];
        $Teacher = $_POST['Teacher'];
        $RollNo = $_POST['RollNo'];
        $query = " UPDATE `indexconnection` set Subject = '".$Subject."',RollNo = '".$RollNo."' ,Teacher = '".$Teacher."' ,Topic = '".$TopicName."' where id='".$ID."'";
        $result = mysqli_query($con,$query);
        // echo $result;
        if($result)
        {
            header("location:dashboard.php");
        }
        else
        {
            echo ' Please Check Your Query ';
        }
    }
    else
    {
        header("location:view.php");
    }


?>
<?php

require_once("dbcon.php");
if(isset($_GET['Del']))
         {
             $ID = $_GET['Del'];
             $query = " UPDATE indexconnection set status=0 where id = '".$ID."'";
             $result = mysqli_query($con,$query);
             if($result)
             {
                 header("location:view.php");
             }
             else
             {
                 echo ' Please Check Your Query ';
             }
        }
         else
         {
             header("location:view.php");
         }
?>