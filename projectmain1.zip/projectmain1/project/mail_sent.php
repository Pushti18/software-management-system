<?php
    session_start();
    include('dbcon.php');  
    $email = $_POST['email'];  
    
    $sql = "SELECT * FROM registration WHERE email = '".$email."'";
    $result = $con->query($sql);
    
    if ($result->num_rows > 0) 
    {
        $row = $result->fetch_assoc();
        $_SESSION["email"] =  $row['email'];  
        header("Location: ./trial_recover.php");
    } 
    else 
    {
        echo "User Does Not Exist";
    }
    $con->close();
?>