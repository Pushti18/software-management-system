<?php

session_start();
ob_start();
?>
<!DOCTYPE html>
<html>
<style>
    @import url('https://fonts.googleapis.com/css?family=Numans');
	@import url('https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap');

html,body{
background-image: url('../project/images/img1.jpg');

background-size: cover;
background-repeat: no-repeat;
height: 100%;
font-family: 'Numans', sans-serif;

}

.container{
	position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
		padding: 3px;
    
}

.card{
height: 350px;

margin-top: auto;
margin-bottom: auto;
width: 400px;
background-color: rgba(0,0,0,0.6) !important;
}

.social_icon span{
font-size: 60px;
margin-left: 10px;
color: #FFC312;
}

.social_icon span:hover{
color: white;
cursor: pointer;
}

.card-header h1{
color: white;
text-align:center;
padding:10px;
font-family: 'Dancing Script', cursive;

}

.social_icon{
position: absolute;
right: 20px;
top: -45px;
}

.input-group-prepend span{
width: 50px;
background-color: #FFC312;
color: black;
border:0 !important;
}

input:focus{
outline: 0 0 0 0  !important;
box-shadow: 0 0 0 0 !important;

}

.remember{
color: white;
}

.remember input
{
width: 20px;
height: 20px;
margin-left: 15px;
margin-right: 5px;
}

.login_btn{
color: black;
background-color: #FFC312;
width: 100px;
}

.login_btn:hover{
color: black;
background-color: white;
}

.links{
color: white;
}

.links a{
margin-left: 4px;
}
img{
    height:150px;
    width:100%;
    border-width:2px;
	border-style:solid;
	padding: 1px 1px 1px 1px;
}

</style>

<head>
    
    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

	 
    <title></title>
    <?php include 'css/style.php' ?>
    <?php include 'links/links.php' ?>
</head>

<body>

    <?php   
include 'dbcon.php';
if(isset($_POST['submit']))
{
    $email =$_POST['email'];
    $Password_new =$_POST['Password_new'];
    
    $email_search = "SELECT * from registration WHERE email = '".$email."' AND Password_new = '".$Password_new."' ";
    $query = $con->query($email_search);

    if($query->num_rows > 0)
    {
      while($row = $query->fetch_assoc())
      {
        error_reporting(E_ERROR | E_PARSE);
        $db_pass = $email_pass['Password_new'];  
        // $_SESSION['Username'] = $email_pass['Username'];
        $pass_decode = password_verify($Password_new,$db_pass);
      
        if($row['category'] == 'user')
        {
            $_SESSION['username'] = $row['Username'];
            $_SESSION['user_id'] = $row['id'];
            echo $_SESSION['username'];
            // exit(0);
            header('Location: ./dashboard.php');
        }
        else if($row['category'] == 'admin')
        {
            $_SESSION['admin'] = $row['Username'];
            header('Location: ./admin.php');
        }
        
      }
    }
    else
    {
        echo "Login failed";
    }
}
?>
<div class="container">

	<div class="d-flex justify-content-center h-100">
	<div class="card mx-auto" style="max-width: 500%;">
			<div class="card-header">
                
				<h1>Sign In</h1>
			
				 
			</div>
			<div class="card-body">
			<form action="" method="POST">
				<div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
                    </div>
                    <input name="email" class="form-control" placeholder="Email address" type="email"
                        value="<?php if(isset($_COOKIE['emailcookie'])) { echo $_COOKIE['emailcookie'];} ?>" required>
                </div>
               
				<div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                    </div>
                    <input class="form-control" placeholder=" password" type="password" name="Password_new"
                        value="<?php if(isset($_COOKIE['passwordcookie'])) { echo $_COOKIE['passwordcookie'];} ?>"
                        required>
                </div>
					<div class="row align-items-center remember">
					<input type="checkbox" name="Rememberme"> Remember me
					</div>
					<div class="form-group">
                    <button type="submit" name="submit" class="btn btn-primary btn-block"> Login </button>
                	</div>
				</form>
			</div>
			<div class="card-footer">
				<div class="d-flex justify-content-center links">
					Don't have an account?<a href="registration.php">Sign Up</a>
				</div>
				<div class="d-flex justify-content-center">
					<a href="reset_table.html">Forgot your password?</a>
				</div>
			</div>
		</div>
	</div>
</div>

</body>

</html>
