<?php
    session_start();

    include('./dbcon.php');
    $random_variable = rand(10000000,99999999);

    echo "Id : ". $_SESSION['email_send'];
    exit(0);
    // $pass = $_POST["email"];

    // $sql = "UPDATE registration SET Password_new = $random_variable, cpassword=$random_variable WHERE email = '". $_SESSION["email"]."'";
    // echo $sql;
    // exit(0);
    // $result = $con->query($sql);

    require_once("./include/PHPMailer.php");    
    require_once("./include/SMTP.php");

    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->Username = 'ax637175@gmail.com';
        $mail->Password = 'abc@1801';

        // Sender and recipient settings
        // $email_id = $_POST['email'];
        $mail->setFrom('ax637175@gmail.com', 'Alumni Portal');
        $mail->addAddress($_GET['mail']);
    
        // Setting the email content
        $mail->IsHTML(true);
        $mail->Subject = "Reset Password";
        $mail->Body = $random_variable;
        $mail->AltBody = $random_variable;

        $mail->send();
        echo "Email message sent.";
    } 
    catch (Exception $e) 
    {
        echo "Error in sending email. Mailer Error: {$mail->ErrorInfo}";
    }
?>




