<?php

    require_once("dbcon.php");

    if(isset($_POST['submit']))
    {
        if(empty($_POST['Topic']))
        {
            echo ' Please Fill in the Blanks ';
        }
        else
        {
            $ID = $_POST['id'];
            $TopicName= $_POST['Topic'];
            $RollNo= $_POST['RollNo'];
            $Subject = $_POST['Subject'];
            $Teacher = $_POST['Teacher'];
            $query = " insert into indexconnection (id,Topic,RollNo,Subject,Teacher,status) values('$ID','$TopicName','$RollNo','$Subject','$Teacher',1)";
            $result = mysqli_query($con,$query);

            if($result)
            {
                header("location:dashboard.php");
            }
            else
            {
                echo '  Please Check Your Query ';
            }
        }
    }
    else
    {
        header("location:index.php");
    }



?>

