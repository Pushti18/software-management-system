<html>
<head>

</head>
<link rel="stylesheet" href="./css/style.css"> 

  <body>
   <!-- <video id = "video"  autoplay muted><source src="../project/video/Rolling Shape Logo_free.mp4" type="video/mp4"><source src="../project/video/Rolling Shape Logo_free.ogg" type="video/ogg"></video>
   <button onclick="_"><a href="./main1.html"></a></button> -->
 
   <!-- <script>
    setTimeout(function(){
       window.location.href = './main1.html';
    }, 13000);
 </script> -->
   <!-- <style>
     #video{
      position: fixed;
  right: 0;
  bottom: 0;
  min-width: 100%;
  min-height: 100%;
     }
    
   </style> -->
   <script>  
   function redirect() {	
     document.location="./project/login.php";  }
     </script> 
     <video id="video" src="./project\video\Rolling Shape Logo_free.mp4" onended="redirect()" autoplay muted><source src="../project/video/Rolling Shape Logo_free.ogg" type="video/ogg"></video>
     <!-- <video id = "video"  autoplay muted><source src="../project/video/Rolling Shape Logo_free.mp4" type="video/mp4"><source src="../project/video/Rolling Shape Logo_free.ogg" type="video/ogg"></video> -->
     <style>
      #video{
   
       position: fixed;
   right: 0;
   bottom: 0;
   min-width: 100%;
   min-height: 100%;
      }
     
    </style>
  </body>
  </html> 
  <!-- <!DOCTYPE html>
  <html>
     <body>
        <script>
           setTimeout(function(){
              window.location.href = '../project/video/Rolling Shape Logo_free.mp4';
           }, 5000);
        </script>
        <p>Web page redirects after 5 seconds.</p>
     </body>
  </html> -->
